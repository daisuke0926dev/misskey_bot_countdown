from datetime import datetime
from misskey import Misskey

def lambda_handler(event, context):
  # インスタンス(サーバー)とアクセストークンをセット
  mk = Misskey("misskey.suzuri.jp")
  mk.token = "V3mMVDOnhHhLR40sKLZxNhbSviOeSNq0"
  today = datetime.now()

  # 指定された日付を作成
  target_date = datetime(2024, 1, 20)

  # 日数の差を計算
  delta = target_date - today + 1

  # 日数の差を返す
  mk.notes_create(text="2024年1月20日まであと" + str(delta.days) + " 日")
